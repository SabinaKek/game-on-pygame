import pygame


WIN_WIDTH = 800
WIN_HEIGHT = 450
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)
BACKGROUND_COLOR = "#004400"

screen = pygame.display.set_mode(DISPLAY)
pygame.display.set_caption('Konoha')

bg = pygame.Surface((WIN_WIDTH, WIN_HEIGHT))
bg.fill(pygame.Color(BACKGROUND_COLOR))

PLATFORM_WIDTH = 40
PLATFORM_HEIGHT = 9
PLATFORM_COLOR = "#FF6262"

level = [
        "--------------------------------------------------",
        "-                    --                          -",
        "-                                                -",
        "-                                                -",
        "-            --                                  -",
        "-                                           -    -",
        "--                          ----                 -",
        "-                                                -",
        "-                   ---                          -",
        "-                                                -",
        "-                               --               -",
        "-      ---                                       -",
        "-                                                -",
        "-                    --                          -",
        "-                                                -",
        "-                                                -",
        "-            --                                  -",
        "-                                           -    -",
        "--                          ----                 -",
        "-                                                -",
        "-                   ---                          -",
        "-                                                -",
        "-                               --               -",
        "-      ---                                       -",
        "-                                                -",
        "-   -----------                         -        -",
        "-                                                -",
        "-                -                    ---        -",
        "-                   --                           -",
        "-                                                -",
        "-       - -                           -          -",
        "-                    --                          -",
        "-                                                -",
        "-                                                -",
        "-            --                                  -",
        "-                                           -    -",
        "--                          ----                 -",
        "-                                                -",
        "-                   ---                          -",
        "-                                                -",
        "-                               --               -",
        "-      ---                                       -",
        "-                                                -",
        "-   -----------                         -        -",
        "-                                                -",
        "-                -                    ---        -",
        "-                   --                           -",
        "-                                                -",
        "-       - -                           -          -",
        "--------------------------------------------------"]
screen.blit(bg, (0, 0))

running = True
while running:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
    x = y = 0
    for row in level:
        for col in row:
            if col == "-":
                pf = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
                pf.fill(pygame.Color(PLATFORM_COLOR))
                screen.blit(pf, (x, y))
            x += PLATFORM_WIDTH
        y += PLATFORM_HEIGHT
        x = 0
    pygame.display.update()
pygame.quit()
