import pygame
import sys
from player import Player
from platforms import Platform, PlatformUP1, PlatformUP2, PlatformUP3, \
    PlatformDOWN1, PlatformDOWN2, PlatformDOWN3, BlockDie, KunaiTeleport, \
    Cat
from monsters import Snake


pygame.init()

WIN_WIDTH = 1600
WIN_HEIGHT = 900
BACKGROUND_COLOR = "#004400"
# BACKGROUND_IMG = pygame.image.load('data/backround_level1_img.png')
FPS = 60

window = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
screen = pygame.Surface((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption('Konoha')

PLATFORM_WIDTH = 200
PLATFORM_HEIGHT = 30


class Background(pygame.sprite.Sprite):
    def __init__(self, img_file, location):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(img_file)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = location


BACKGROUND_IMG = Background('data/backround_level1_img2.png', [0, 0])
BACKGROUND_MENU = Background('data/menu.png', [0, 0])


class Menu(pygame.sprite.Sprite):
    def __init__(self, punkts=[120, 140, u'Punkt', (250, 250, 30), (250, 30, 250), 1]):
        pygame.sprite.Sprite.__init__(self)
        self.punkts = punkts

    def render(self, holst, font, num_punkt):
        for i in self.punkts:
            if num_punkt == i[5]:
                holst.blit(font.render(i[2], 1, i[4]), (i[0], i[1]))
            else:
                holst.blit(font.render(i[2], 1, i[3]), (i[0], i[1]))

    def menu(self):
        running = True
        font_menu = pygame.font.Font('fonts/WhiteyFord.ttf', 100)
        pygame.key.set_repeat(0, 0)
        pygame.mouse.set_visible(True)
        punkt = 0

        while running:
            screen.fill((0, 100, 200))
            screen.blit(BACKGROUND_MENU.image, BACKGROUND_MENU.rect)

            mp = pygame.mouse.get_pos()
            for i in self.punkts:
                if mp[0] > i[0] and mp[0] < i[0] + 205 and mp[1] > i[1] and mp[1] < i[1] + 100:
                    punkt = i[5]
            self.render(screen, font_menu, punkt)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        sys.exit()
                    if event.key == pygame.K_UP:
                        if punkt > 0:
                            punkt -= 1
                    if event.key == pygame.K_DOWN:
                        if punkt < len(self.punkts) - 1:
                            punkt += 1

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if punkt == 0:
                        running = False
                    elif punkt == 1:
                        sys.exit()

            # BACKGROUND_MENU.update()

            window.blit(screen, (0, 0))
            pygame.display.flip()


class Animation:
    def __init__(self, sprites=None, time=100):
        self.sprites = sprites
        self.time = time
        self.work_time = 0
        self.skip_frame = 0
        self.frame = 0

    def update(self, dt):
        self.work_time += dt
        self.skip_frame = self.work_time / self.time
        if self.skip_frame > 0:
            self.work_time = self.work_time % self.time
            self.frame += self.skip_frame
            if self.frame >= len(self.sprites):
                self.frame = 0

    def get_sprite(self):
        return self.sprites(self.frame)


# long_platform = pygame.transform.scale(load_image('long_stone.png'), (80, 18))


def terminate():
    pygame.quit()
    sys.exit()


'''time = 180
right_1 = pygame.image.load('right_1.png')
right_2 = pygame.image.load('right_2.png')
right_3 = pygame.image.load('right_3.png')
right_4 = pygame.image.load('right_4.png')
right_5 = pygame.image.load('right_5.png')
right_6 = pygame.image.load('right_6.png')
right_7 = pygame.image.load('right_1.png')
anim = []
anim.append(pygame.transform.scale(right_1, (50, 50)))
anim.append(pygame.transform.scale(right_2, (50, 50)))
anim.append(pygame.transform.scale(right_3, (50, 50)))
anim.append(pygame.transform.scale(right_4, (50, 50)))
anim.append(pygame.transform.scale(right_5, (50, 50)))
anim.append(pygame.transform.scale(right_6, (50, 50)))
anim.append(pygame.transform.scale(right_7, (50, 50)))

hero1 = Animation(anim, time)

clock = pygame.time.Clock()
dt = 0'''


hero = Player(200, 55)
left = False
right = False
up = False
run = False

level = [
        ".                                           ,",
        ".                                           ,",
        ".            --                             ,",
        ".                                           ,",
        ".-                                          ,",
        ".                                           ,",
        ".                                           ,",
        ".                                   -       ,",
        ".                       ---                 ,",
        ".                                           ,",
        ".            --                          -  ,",
        ".                                   -       ,",
        ".-                         A--C             ,",
        ".                                           ,",
        ".                   A-C                     ,",
        ".                                           ,",
        ".               A---C                      AD",
        ".        -     A,.            AC           ,D",
        ".                             ,.           ,D",
        "DC AC                                       ,",
        "D.                                          ,",
        ".        A-C           A-C                  ,",
        ".                                           ,",
        ".               -            -              ,",
        ".                            D              ,",
        ".                                A--C     A-D",
        ".      A-C                                  ,",
        ".                A------*--C          -     ,",
        ". -                                         ,",
        ".           -                  A-C        - ,",
        ".    -               AC        ,D.          ,",
        ".      K     *       ,.               -     ,",
        ".        AC          ,DAC                   ,",
        "D--------,.----------,DD.-------------------D"]

animatedEntities = pygame.sprite.Group()
sprites_group = pygame.sprite.Group()
sprites_group.add(hero)
platforms = []

x = y = 0
for row in level:
    for col in row:
        if col == "-":
            pf = PlatformUP2(x, y)
            sprites_group.add(pf)
            platforms.append(pf)
        if col == "A":
            pf = PlatformUP1(x, y)
            sprites_group.add(pf)
            platforms.append(pf)
        if col == "C":
            pf = PlatformUP3(x, y)
            sprites_group.add(pf)
            platforms.append(pf)
        if col == ".":
            pf = PlatformDOWN3(x, y)
            sprites_group.add(pf)
            platforms.append(pf)
        if col == ",":
            pf = PlatformDOWN1(x, y)
            sprites_group.add(pf)
            platforms.append(pf)
        if col == "D":
            pf = PlatformDOWN2(x, y)
            sprites_group.add(pf)
            platforms.append(pf)
        if col == "*":
            pf = BlockDie(x, y)
            sprites_group.add(pf)
            platforms.append(pf)
        if col == "K":
            kitten = Cat(x, y)
            sprites_group.add(kitten)
            platforms.append(kitten)
            animatedEntities.add(kitten)

        x += 60
    y += 60
    x = 0

tp = KunaiTeleport(120, 1500, 800, 60)
sprites_group.add(tp)
platforms.append(tp)
animatedEntities.add(tp)

snakes = pygame.sprite.Group()
sn = Snake(200, 300, 2, 3, 150, 15)
sprites_group.add(sn)
platforms.append(sn)
snakes.add(sn)


# камера
class Camera:
    def __init__(self, camera_func, width, height):
        self.camera_func = camera_func
        self.state = pygame.Rect(0, 0, width, height)

    def apply(self, target):
        return target.rect.move(self.state.topleft)

    def update(self, target):
        self.state = self.camera_func(self.state, target.rect)


def camera_func(camera, target_rect):
    l = -target_rect.x + WIN_WIDTH / 2
    t = -target_rect.y + WIN_HEIGHT / 2
    w, h = camera.width, camera.height

    l = min(0, l)
    l = max(-(camera.width - WIN_WIDTH), l)
    t = min(t, 0)
    t = max(-(camera.height - WIN_HEIGHT), t)

    return pygame.Rect(l, t, w, h)


total_level_width = len(level[0]) * 60
total_level_height = len(level) * 60

camera = Camera(camera_func, total_level_width, total_level_height)

'''pygame.mixer.pre_init(44100, -16, 1, 8192)
pygame.mixer.init()
sound = pygame.mixer.Sound('sounds/CHABA - Naruto ending 12 - Parade (1-12)_(Inkompmusic.ru) (1) (1).ogg')
sound.play(-1)'''

punkts = [(1240, 170, u'Game', (145, 10, 100), (250, 30, 180), 0),
          (1270, 270, u'Quit', (145, 10, 100), (250, 30, 180), 1)]
game = Menu(punkts)
game.menu()

running = True
timer = pygame.time.Clock()
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                left = True
            if event.key == pygame.K_RIGHT:
                right = True
            if event.key == pygame.K_UP:
                up = True
            if event.key == pygame.K_LSHIFT:
                run = True

            if event.key == pygame.K_ESCAPE:
                game.menu()
                pygame.key.set_repeat(1, 1)
                pygame.mouse.set_visible(False)
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_RIGHT:
                right = False
            if event.key == pygame.K_LEFT:
                left = False
            if event.key == pygame.K_UP:
                up = False
            if event.key == pygame.K_LSHIFT:
                run = False

    screen.fill(pygame.Color(BACKGROUND_COLOR))

    screen.blit(BACKGROUND_IMG.image, BACKGROUND_IMG.rect)

    hero.update(left, right, up, run, platforms)
    animatedEntities.update()
    snakes.update(platforms)
    camera.update(hero)
    for s in sprites_group:
        screen.blit(s.image, camera.apply(s))
    # sprites_group.draw(screen)

    window.blit(screen, (0, 0))
    pygame.display.flip()
    timer.tick(FPS)
terminate()
