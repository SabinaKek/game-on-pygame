import pygame
import os
import sys


pygame.init()

BACKGROUND_COLOR = "#004400"
WIN_WIDTH = 1600
WIN_HEIGHT = 900

screen = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption('Konoha')

bg = pygame.Surface((WIN_WIDTH, WIN_HEIGHT))

PLATFORM_WIDTH = 80
PLATFORM_HEIGHT = 18
PLATFORM_COLOR = "#FF6262"


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    image = image.convert_alpha()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    return image


def terminate():
    pygame.quit()
    sys.exit()


'''x = 10
y = 385
width = 50
height = 50
step = 5
color = '#888888'

right_1 = pygame.transform.scale(load_image('right_1.png'), (width, height))
right_2 = pygame.transform.scale(load_image('right_2.png'), (width, height))
right_3 = pygame.transform.scale(load_image('right_3.png'), (width, height))
right_4 = pygame.transform.scale(load_image('right_4.png'), (width, height))
right_5 = pygame.transform.scale(load_image('right_5.png'), (width, height))
right_6 = pygame.transform.scale(load_image('right_6.png'), (width, height))

left_1 = pygame.transform.scale(load_image('left_1.png'), (width, height))
left_2 = pygame.transform.scale(load_image('left_2.png'), (width, height))
left_3 = pygame.transform.scale(load_image('left_3.png'), (width, height))
left_4 = pygame.transform.scale(load_image('left_4.png'), (width, height))
left_5 = pygame.transform.scale(load_image('left_5.png'), (width, height))
left_6 = pygame.transform.scale(load_image('left_6.png'), (width, height))

walkRight = [right_1, right_2, right_3,
             right_4, right_5, right_6]

walkLeft = [left_1, left_2, left_3,
            left_4, left_5, left_6]

player_facing = pygame.transform.scale(load_image('facing.png'), (width, height))
player_backside = pygame.transform.scale(load_image('backside.png'), (width, height))
forest = load_image('forest.jpg')

long_platform = pygame.transform.scale(load_image('long_stone.png'), (200, 40))
big_platform = pygame.transform.scale(load_image('big_stone.png'), (100, 50))'''

'''x = 10
y = 385
width = 50
height = 50
step = 5
color = '#888888'''''


'''class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.x_v = 0  # скорость перемещения
        self.startX = x
        self.startY = y
        self.image = pygame.Surface((width, height))
        self.image.fill(pygame.Color(color))
        self.rect = pygame.Rect(x, y, width, height)

    def update(self, left, right):
        if left:
            self.x_v = -step
        if right:
            self.x_v = step
        if not (left or right):
            self.x_v = 0
        self.rect.x += self.x_v

    def draw(self, screen):
        screen.blit(self.image, (self.rect.x, self.rect.y))'''


'''left = False
right = False
hero = Player(55, 55)
animate_count = 0'''


def make_level(level, pf):
    x2 = y2 = 0
    for row in level:
        for col in row:
            if col == "-":
                pf = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
                pf.fill(pygame.Color(PLATFORM_COLOR))
                screen.blit(pf, (x2, y2))
            x2 += 18
        y2 += 80
        x2 = 0


level = [
        "--------------------",
        "-       --         -",
        "-                  -",
        "-                  -",
        "-            --    -",
        "-   -              -",
        "--      ----       -",
        "-                  -",
        "-            ---   -",
        "-                  -",
        "- --               -",
        "-      ---         -",
        "-                  -",
        "-       --         -",
        "-                  -",
        "-                  -",
        "-            --    -",
        "-    -             -",
        "--        ----     -",
        "-                  -",
        "-                  -",
        "-                  -",
        "-                  -",
        "-      ---         -",
        "-                  -",
        "-   -----------    -",
        "-                  -",
        "- -      ---       -",
        "-            --    -",
        "-                  -",
        "-       - -        -",
        "-   --             -",
        "-                  -",
        "-                  -",
        "-            --    -",
        "-       -          -",
        "--           ----  -",
        "-                  -",
        "-   ---            -",
        "-                  -",
        "-                  -",
        "-      ---         -",
        "-                  -",
        "-   -----------    -",
        "-                  -",
        "-                - -",
        "-                  -",
        "-                  -",
        "-       - -        -",
        "--------------------"]

'''jumping = False
jump_count = 10'''

running = True
while running:
    pygame.time.delay(50)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        '''if event.type == pygame.KEYDOWN and event.key == pygame.K_LEFT:
            left = True
        if event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT:
            right = True
        if event.type == pygame.KEYUP and event.key == pygame.K_RIGHT:
            right = False
        if event.type == pygame.KEYUP and event.key == pygame.K_LEFT:
            left = False'''

    bg.fill(pygame.Color(BACKGROUND_COLOR))
    make_level(level, pf)

    '''x = y = 0
    for row in level:
        for col in row:
            if col == "-":
                pf = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
                pf.fill(pygame.Color(PLATFORM_COLOR))
                screen.blit(pf, (x, y))
            x += PLATFORM_WIDTH
        y += PLATFORM_HEIGHT
        x = 0'''

    '''x2 = y2 = 0
    for row in level:
        for col in row:
            if col == "-":
                pf = pygame.Surface((200, 40))
                pf.fill(pygame.Color(PLATFORM_COLOR))
                screen.blit(pf, (x2, y2))
            x2 += 200
            y2 += 40
            x2 = 0
            if col == ".":
                pf = pygame.Surface((200, 40))
                pf.fill(pygame.Color(PLATFORM_COLOR))
                screen.blit(pf, (x2, y2))
            x2 += 200
        y2 += 40
        x2 = 0'''

    '''keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        x -= step
    if keys[pygame.K_RIGHT]:
        x += step
    if keys[pygame.K_UP]:
        y -= step
    if keys[pygame.K_DOWN]:
        y += step'''
    '''for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_LEFT:
            left = True
        if event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT:
            right = True
        if event.type == pygame.KEYUP and event.key == pygame.K_RIGHT:
            right = False
        if event.type == pygame.KEYUP and event.key == pygame.K_LEFT:
            left = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and x > 5:
        x -= step
    if keys[pygame.K_RIGHT] and x < 800 - width - 5:
        x += step
    if not jumping:
        if keys[pygame.K_DOWN] and y < 450 - height - 5:
            y += step
        if keys[pygame.K_UP] and y > 5:
            y -= step
        if keys[pygame.K_SPACE]:
            jumping = True
    else:
        # прыжок по параболе
        if jump_count >= -10:
            if jump_count < 0:
                y += (jump_count ** 2) / 2
            else:
                y -= (jump_count ** 2) / 2
            jump_count -= 1
        else:
            jumping = False
            jump_count = 10'''

    # pygame.draw.rect(screen, (255, 0, 0), (x, y, width, height))
    screen.blit(bg, (0, 0))
    pygame.display.update()
    '''hero.update(left, right)
    hero.draw(screen)'''
terminate()
