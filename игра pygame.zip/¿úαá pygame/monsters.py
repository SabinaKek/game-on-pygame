import pygame
import pyganim
import os


SNAKE_HEIGHT = 30
SNAKE_WIDTH = 100
SNAKE_COLOR = "#2110FF"

snakeMotion = ['data/snake2_1.png',
               'data/snake2_2.png']


class Snake(pygame.sprite.Sprite):
    def __init__(self, x, y, left, up, maxLengthLeft, maxLengthUp):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((SNAKE_WIDTH, SNAKE_HEIGHT))
        self.image.fill((0, 0, 0))
        self.rect = pygame.Rect(x, y, SNAKE_WIDTH, SNAKE_HEIGHT)
        self.image.set_colorkey((0, 0, 0))
        self.startX = x
        self.startY = y
        self.maxLengthLeft = maxLengthLeft
        self.maxLengthUp = maxLengthUp
        self.x_v = left
        self.y_v = up

        boltAnim = []
        for anim in snakeMotion:
            boltAnim.append((anim, 0.3))
        self.boltAnim = pyganim.PygAnimation(boltAnim)
        self.boltAnim.play()

    def update(self, platforms):

        self.image.fill((0, 0, 0))
        self.boltAnim.blit(self.image, (0, 0))

        self.rect.y += self.y_v
        self.rect.x += self.x_v

        self.collide(platforms)

        if (abs(self.startX - self.rect.x) > self.maxLengthLeft):
            self.x_v = -self.x_v

        if (abs(self.startY - self.rect.y) > self.maxLengthUp):
            self.y_v = -self.y_v

    def collide(self, platforms):
        for pf in platforms:
            if pygame.sprite.collide_rect(self, pf) and self != pf:
                self.x_v = - self.x_v
                self.y_v = - self.y_v
