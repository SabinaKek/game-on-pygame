import pygame


class Animation:
    def __init__(self, sprites=None, time=100):
        self.sprites = sprites
        self.time = time
        self.work_time = 0
        self.skip_frame = 0
        self.frame = 0

    def update(self, dt):
        self.work_time += dt
        self.skip_frame = self.work_time / self.time
        if self.skip_frame > 0:
            self.work_time = self.work_time % self.time
            self.frame += self.skip_frame
            if self.frame >= len(self.sprites):
                self.frame = 0

    def get_sprite(self):
        return self.sprites[self.frame]


pygame.init()

window = pygame.display.set_mode((100, 100))
screen = pygame.Surface((100, 100))

time = 180
sprite = pygame.image.load('data/naruto_left2.png').convert_alpha()

anim = []
anim.append(sprite.subsurface((0, 0, 100, 100)))
anim.append(sprite.subsurface((100, 0, 100, 100)))
anim.append(sprite.subsurface((200, 0, 100, 100)))
anim.append(sprite.subsurface((300, 0, 100, 100)))
anim.append(sprite.subsurface((400, 0, 100, 100)))
anim.append(sprite.subsurface((500, 0, 100, 100)))
anim.append(sprite.subsurface((0, 0, 100, 100)))

hero = Animation(anim, time)

clock = pygame.time.Clock()
dt = 0

running = False
while not running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = True
    hero.update(dt)
    screen.fill((255, 255, 255))
    screen.blit(hero.get_sprite(), (0, 0))
    window.blit(screen, (0, 0))
    pygame.display.flip()

    dt = clock.tick(40)
