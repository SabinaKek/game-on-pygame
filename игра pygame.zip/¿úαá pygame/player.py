import pygame
import pyganim
from platforms import BlockDie, KunaiTeleport, Cat
from monsters import Snake


width = 100
height = 100
step = 8
jump_count = 15
gravity = 0.8
animation_delay = 0.1

move_extra_speed = 4  # Ускорение
jump_extra_power = 2  # дополнительная сила прыжка
animation_super_speed_delay = 0.05  # скорость смены кадров при ускорении

narutoStay = [('data/facing.png', animation_delay)]

walkRight = ['data/right_1.png',
             'data/right_2.png',
             'data/right_3.png',
             'data/right_4.png',
             'data/right_5.png',
             'data/right_6.png']

walkLeft = ['data/left_1.png',
            'data/left_2.png',
            'data/left_3.png',
            'data/left_4.png',
            'data/left_5.png',
            'data/left_6.png']


class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((width, height))
        self.x_v = 0
        self.y_v = 0
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.onGround = False

        self.startX = x
        self.startY = y

        self.image.set_colorkey((0, 0, 0))

        def make_boltAnim(anim_list, delay):
            boltAnim = []
            for anim in anim_list:
                boltAnim.append((anim, delay))
            Anim = pyganim.PygAnimation(boltAnim)
            return Anim

        def make_super_boltAnim(anim_list, delay):
            boltAnimSuperSpeed = []
            for anim in anim_list:
                boltAnimSuperSpeed.append((anim, delay))
            SuperAnim = pyganim.PygAnimation(boltAnimSuperSpeed)
            return SuperAnim

        self.boltAnimStay = pyganim.PygAnimation(narutoStay)
        self.boltAnimStay.play()

        self.boltAnimRight = make_boltAnim(walkRight, animation_delay)
        self.boltAnimRight.play()

        self.boltAnimLeft = make_boltAnim(walkLeft, animation_delay)
        self.boltAnimLeft.play()

        self.boltSuperAnimLeft = make_super_boltAnim(walkLeft, animation_super_speed_delay)
        self.boltSuperAnimLeft.play()

        self.boltSuperAnimRight = make_super_boltAnim(walkRight, animation_super_speed_delay)
        self.boltSuperAnimRight.play()

        self.winner = False

    def update(self, left, right, up, run, platforms):
        if up:
            if self.onGround:
                self.y_v = -jump_count
                if run and (left or right):
                    self.y_v -= jump_extra_power

        if left:
            self.x_v = -step
            if run:
                self.x_v -= move_extra_speed
                if not up:
                    self.image.fill((0, 0, 0))
                    self.boltSuperAnimLeft.blit(self.image, (0, 0))
            else:
                if not up:
                    self.image.fill((0, 0, 0))
                    self.boltAnimLeft.blit(self.image, (0, 0))

        if right:
            self.x_v = step
            if run:
                self.x_v += move_extra_speed
                if not up:
                    self.image.fill((0, 0, 0))
                    self.boltSuperAnimRight.blit(self.image, (0, 0))
            else:
                if not up:
                    self.image.fill((0, 0, 0))
                    self.boltAnimRight.blit(self.image, (0, 0))

        if not (left or right):
            self.x_v = 0
            if not up:
                self.image.fill((0, 0, 0))
                self.boltAnimStay.blit(self.image, (0, 0))

        if not self.onGround:
            self.y_v += gravity

        self.onGround = False
        self.rect.x += self.x_v
        self.collision(self.x_v, 0, platforms)
        self.rect.y += self.y_v
        self.collision(0, self.y_v, platforms)

    def collision(self, x_v, y_v, platforms):
        for pf in platforms:
            if pygame.sprite.collide_rect(self, pf):
                if x_v > 0:
                    self.rect.right = pf.rect.left
                if x_v < 0:
                    self.rect.left = pf.rect.right
                if y_v > 0:
                    self.rect.bottom = pf.rect.top
                    self.onGround = True
                    self.y_v = 0
                if y_v < 0:
                    self.rect.top = pf.rect.bottom
                    self.y_v = 0
                if isinstance(pf, BlockDie) or isinstance(pf, Snake):
                    self.die()
                elif isinstance(pf, KunaiTeleport):
                    self.teleporting(pf.goX, pf.goY)
                elif isinstance(pf, Cat):  # если коснулись кошки
                    self.winner = True  # победили/окончание миссии

    def die(self):
            pygame.time.wait(300)
            self.teleporting(self.startX, self.startY)

    def teleporting(self, goX, goY):
            self.rect.x = goX
            self.rect.y = goY


'''jumping = False
jump_count = 10
keys = pygame.key.get_pressed()
if not jumping:
        if keys[pygame.K_DOWN] and y < 450 - height - 5:
            y += step
        if keys[pygame.K_UP] and y > 5:
            y -= step
        if keys[pygame.K_SPACE]:
            jumping = True
    else:
        # прыжок по параболе
        if jump_count >= -10:
            if jump_count < 0:
                y += (jump_count ** 2) / 2
            else:
                y -= (jump_count ** 2) / 2
            jump_count -= 1
        else:
            jumping = False
            jump_count = 10'''
