import pygame
import pyganim


animation_delay = 0.3
animation_delay_2 = 0.8
kunaiTeleport = ['data/кунай телепорт.png',
                 'data/кунай телепорт.png']

catAnimation = ['data/cat_1.png',
                'data/cat_2.png']


class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('data/long_stone4.png')
        # self.image_big = load('data/long_stone3.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class PlatformUP1(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('data/pf_up1.png')
        # self.image_big = load('data/long_stone3.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class PlatformUP2(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('data/pf_up2.png')
        # self.image_big = load('data/long_stone3.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class PlatformUP3(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('data/pf_up3.png')
        # self.image_big = load('data/long_stone3.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class PlatformDOWN1(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('data/pf_down1.png')
        # self.image_big = load('data/long_stone3.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class PlatformDOWN2(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('data/pf_down2.png')
        # self.image_big = load('data/long_stone3.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class PlatformDOWN3(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('data/pf_down3.png')
        # self.image_big = load('data/long_stone3.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class BlockDie(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('data/block_of_death.png')
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class KunaiTeleport(pygame.sprite.Sprite):
    def __init__(self, x, y, goX, goY):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((50, 60))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.goX = goX
        self.goY = goY

        self.image.set_colorkey((0, 0, 0))

        boltAnim = []
        for anim in kunaiTeleport:
            boltAnim.append((anim, animation_delay))

        self.boltAnimKunai = pyganim.PygAnimation(boltAnim)
        self.boltAnimKunai.play()

    def update(self):
        self.image.fill((0, 0, 0))
        self.boltAnimKunai.blit(self.image, (0, 0))


class Cat(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((50, 50))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.image.set_colorkey((0, 0, 0))

        boltAnim = []
        for anim in catAnimation:
            boltAnim.append((anim, animation_delay_2))

        self.boltAnimCat = pyganim.PygAnimation(boltAnim)
        self.boltAnimCat.play()

    def update(self):
        self.image.fill((0, 0, 0))
        self.boltAnimCat.blit(self.image, (0, 0))
