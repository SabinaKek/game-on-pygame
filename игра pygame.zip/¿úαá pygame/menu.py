import pyglet


animMenu = ('data/menu2_1.png',
            'data/menu2_2.png',
            'data/menu2_3.png',
            'data/menu2_4.png',
            'data/menu2_5.png',
            'data/menu2_6.png',
            'data/menu2_7.png',
            'data/menu2_8.png',
            'data/menu2_9.png',
            'data/menu2_1.png')


images_menu = map(lambda img: pyglet.image.load(img), animMenu)
animation_menu = pyglet.image.Animation.from_image_sequence(images_menu, 0.3)
animSprite = pyglet.sprite.Sprite(animation_menu)
w = animSprite.width
h = animSprite.height
win = pyglet.window.Window(width=w, height=h)
pyglet.gl.glClearColor(1, 1, 1, 1)


@win.event
def on_draw():
    win.clear()
    animSprite.draw()


pyglet.app.run()
